using loginReg.Models;

namespace loginReg.Factory
{
	public interface IFactory<T> where T : BaseEntity
	{
	}
}